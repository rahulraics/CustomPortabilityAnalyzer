﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Migra
{
    public class Assembly
    {
        public string Namespace { get; set; }
        public string Dll { get; set; }
    }
}
