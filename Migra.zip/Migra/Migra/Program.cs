﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace Migra
{
    class Program
    {
        public static readonly Uri PrivacyPolicy = new Uri("https://privacy.microsoft.com/en-us/privacystatement");

        public static readonly Uri About = new Uri("https://aka.ms/dotnet-portabilityanalyzer");

        static void Main(string[] args)
        {
           
            Console.WriteLine("Header", "ApplicationName", "informationalVersion", "About", "PrivacyPolicy");
            //getAllProjects();
        }

        private static void getAllProjects()
        {
            var Content = File.ReadAllText(@"C:\Users\Rahul\source\repos\Migra\Migra.sln");
            Regex projReg = new Regex(
                "Project\\(\"\\{[\\w-]*\\}\"\\) = \"([\\w _]*.*)\", \"(.*\\.(cs|vcx|vb)proj)\""
                , RegexOptions.Compiled);
            var matches = projReg.Matches(Content).Cast<Match>();
            var Projects = matches.Select(x => x.Groups[2].Value).ToList();
            for (int i = 0; i < Projects.Count; ++i)
            {
                if (!Path.IsPathRooted(Projects[i]))
                    Projects[i] = Path.Combine(Path.GetDirectoryName(@"C:\Users\Rahul\source\repos\Migra\Migra.sln"),
                        Projects[i]);
                Projects[i] = Path.GetFullPath(Projects[i]);
               // getType(Projects[i]);
            }
            getProjectType(Projects[1]);
            getProjectReference(Projects[1]);
        }

        private static string getProjectType(string path)
        {
            XNamespace msbuild = "http://schemas.microsoft.com/developer/msbuild/2003";
            XDocument projDefinition = XDocument.Load(path);
            var type = projDefinition
               .Elements(msbuild + "Project")
               .Elements(msbuild + "PropertyGroup")
               .Select(x => x.Element(msbuild + "OutputType").Value).FirstOrDefault();

            return type;

        }

        private static List<Assembly> getProjectReference(string path)
        {
            List<Assembly> assemblies = new List<Assembly>();

            XNamespace msbuild = "http://schemas.microsoft.com/developer/msbuild/2003";
            XDocument projDefinition = XDocument.Load(path);

            IEnumerable<string> references = projDefinition
                            .Element(msbuild + "Project")
                            .Elements(msbuild + "ItemGroup")
                            .Elements(msbuild + "Reference")
                            .Select(refElem => refElem.Value);

            foreach (string reference in references)
            {
                if (!String.IsNullOrEmpty(reference))
                {
                    Assembly assembly = new Assembly();
                    int firstSlashPosition = reference.IndexOf('\\');
                    int SecondSlashPosition = reference.IndexOf('\\', firstSlashPosition + 1);
                    int thridSlashPosition = reference.IndexOf('\\', SecondSlashPosition + 1);
                    int lastSlashPostion = reference.LastIndexOf('\\') + 1;
                    assembly.Namespace = reference.Substring(SecondSlashPosition + 1, (thridSlashPosition - SecondSlashPosition) - 1);
                    assembly.Dll = reference.Substring(lastSlashPostion, reference.Length - lastSlashPostion);
                    assemblies.Add(assembly);
                }
             
            }

            return assemblies;

        }
    }
}
